// Veritas Kernel V0.3 - Kernel wrapper for VeritasEngine
//
// Phase 1: Thin wrapper that delegates all calls to the real VeritasEngine.
// Future phases will restrict access to TRAP-only kernel services.

use crate::engine::VeritasEngine;
use crate::types::*;

/// Kernel wraps VeritasEngine and serves as the world state authority.
///
/// In Phase 1, this is a thin pass-through wrapper. Machine accesses
/// Engine methods through Kernel, but the full API surface is unchanged.
///
/// In Phase 2, Kernel will restrict access to TRAP-only kernel services
/// and Machine will no longer call Engine methods directly.
/// KernelCall represents a decoded kernel service request.
///
/// Machine decodes raw register values (r0, r1, r2) into this enum,
/// then passes it to Kernel::handle(). Machine never calls kernel
/// methods directly for kernel services.
#[derive(Debug, Clone)]
pub enum KernelCall {
    ObjectBirth {
        object_type: ObjectType,
    },
    ObjectDeath {
        object_id: ObjectId,
    },
    ObjectLink {
        from: ObjectId,
        to: ObjectId,
        link_type: LinkType,
    },
    ObjectUnlink {
        from: ObjectId,
        to: ObjectId,
    },
    ObjectFreeze {
        object_id: ObjectId,
    },
    Abort {
        reason: AbortReason,
    },
    CapabilityGrant {
        grantor: ObjectId,
        grantee: ObjectId,
        capability_type: String,
        resource: ObjectId,
    },
    /// Revoke a holder's capability. Cascade follows the edge setting
    /// unless cascade_override is Some(...). Constitution §3.6 is the
    /// cascade=true case (full downstream revocation).
    CapabilityRevoke {
        capability_id: CapabilityId,
        holder: ObjectId,
        /// None → use DelegationEdge.cascade_on_revoke (root defaults true).
        cascade_override: Option<bool>,
    },
    /// Add a holder edge under an existing capability (no new CapabilityId).
    CapabilityDelegate {
        capability_id: CapabilityId,
        from: ObjectId,
        to: ObjectId,
        cascade_on_revoke: bool,
    },
    MemoryAlloc {
        object_id: ObjectId,
        size_hint: u64,
    },
    Commit,
    Effect {
        payload: Vec<u8>,
    },
    Savepoint {
        name: String,
    },
    RollbackTo {
        name: String,
    },
}
// ===== Phase 1 Step 7: KernelCall ABI codec =====

impl KernelCall {
    /// Decode register values from a TRAP instruction into a KernelCall.
    /// This is the Veritas TRAP ABI: service_id selects the operation,
    /// r0/r1/r2 carry operands.
    pub fn decode(
        service_id: u8,
        r0: u64,
        r1: u64,
        r2: u64,
    ) -> Result<Self, crate::types::VeritasError> {
        match service_id {
            0 => Ok(KernelCall::ObjectBirth {
                object_type: if r0 == 0 {
                    crate::types::ObjectType::StateObject
                } else {
                    crate::types::ObjectType::ModuleObject
                },
            }),
            1 => Ok(KernelCall::ObjectDeath { object_id: r0 }),
            2 => {
                let link_type = match r2 as u8 {
                    0 => crate::types::LinkType::DependsOn,
                    1 => crate::types::LinkType::Owns,
                    2 => crate::types::LinkType::References,
                    _ => {
                        return Err(crate::types::VeritasError::EngineError(format!(
                            "Invalid LinkType: {}",
                            r2
                        )))
                    }
                };
                Ok(KernelCall::ObjectLink {
                    from: r0,
                    to: r1,
                    link_type,
                })
            }
            3 => Ok(KernelCall::ObjectUnlink { from: r0, to: r1 }),
            4 => Ok(KernelCall::ObjectFreeze { object_id: r0 }),
            5 => Ok(KernelCall::Commit),
            6 => Ok(KernelCall::Effect { payload: vec![] }),
            7 => Ok(KernelCall::Savepoint {
                name: String::new(),
            }),
            8 => Ok(KernelCall::RollbackTo {
                name: String::new(),
            }),
            _ => Err(crate::types::VeritasError::EngineError(format!(
                "Unknown kernel service_id: {}",
                service_id
            ))),
        }
    }
}

/// TrapResult is returned by Kernel::handle() after processing a KernelCall.
/// The result is written to register r0 by Machine.
#[derive(Debug, Clone)]
pub enum TrapResult {
    ObjectId(ObjectId),
    CapabilityId(CapabilityId),
    StateId(StateId),
    EffectKey(String),
    Success,
}

pub struct Kernel {
    engine: VeritasEngine,
}

impl Kernel {
    pub fn new() -> Self {
        Kernel {
            engine: VeritasEngine::new(),
        }
    }

    pub fn with_wal_path(wal_path: String) -> Self {
        Kernel {
            engine: VeritasEngine::with_wal_path(wal_path),
        }
    }

    /// Internal engine access for same-crate runtime (Machine / WorldService).
    /// Production external callers must not use this; use handle() or WorldService.
    pub(crate) fn engine(&self) -> &VeritasEngine {
        &self.engine
    }

    /// Replay: 从 WAL 重放全部已提交事务，返回最终 WorldState 根哈希。
    /// 从空 WorldState 出发，不保留引擎用于后续操作。
    /// 用于验证 WAL 的确定性——Replay(WAL) == 原始执行结束时的 root_hash()。
    pub fn replay(wal_path: &str) -> u64 {
        let (records, _) =
            crate::wal::RecoveryManager::recover(wal_path).unwrap_or_else(|_| (vec![], 0));
        let ordered_deltas = crate::wal::build_ordered_deltas(&records);
        let engine = VeritasEngine::empty();
        for delta in &ordered_deltas {
            engine.apply(delta);
        }
        engine.root_hash()
    }

    // ===== Phase 1 Step 4: KernelCall dispatch =====

    /// Handle a decoded kernel service call.
    /// This is the single entry point for all kernel services.
    /// Machine calls this instead of individual kernel methods.
    pub fn handle(
        &self,
        ctx: &mut TransactionContext,
        call: KernelCall,
    ) -> Result<TrapResult, VeritasError> {
        match call {
            KernelCall::ObjectBirth {
                object_type: _object_type,
            } => {
                // Step 3/ObjectId: Kernel allocates ObjectId internally
                let id = self.engine.next_object_id();
                self.engine.object_birth(ctx, id)?;
                Ok(TrapResult::ObjectId(id))
            }
            KernelCall::ObjectDeath { object_id } => {
                self.engine.object_death(ctx, object_id)?;
                Ok(TrapResult::Success)
            }
            KernelCall::ObjectLink {
                from,
                to,
                link_type,
            } => {
                self.engine.object_link(ctx, from, to, link_type)?;
                Ok(TrapResult::Success)
            }
            KernelCall::ObjectUnlink { from, to } => {
                self.engine.object_unlink(ctx, from, to)?;
                Ok(TrapResult::Success)
            }
            KernelCall::ObjectFreeze { object_id } => {
                self.engine.object_freeze(ctx, object_id)?;
                Ok(TrapResult::Success)
            }
            KernelCall::CapabilityGrant {
                grantor,
                grantee,
                capability_type,
                resource,
            } => {
                let cap_id = self.engine.capability_grant(
                    ctx,
                    grantor,
                    grantee,
                    &capability_type,
                    resource,
                )?;
                Ok(TrapResult::CapabilityId(cap_id))
            }
            KernelCall::CapabilityRevoke {
                capability_id,
                holder,
                cascade_override,
            } => {
                self.engine
                    .capability_revoke(ctx, capability_id, holder, cascade_override)?;
                Ok(TrapResult::Success)
            }
            KernelCall::CapabilityDelegate {
                capability_id,
                from,
                to,
                cascade_on_revoke,
            } => {
                self.engine
                    .capability_delegate(ctx, capability_id, from, to, cascade_on_revoke)?;
                Ok(TrapResult::Success)
            }
            KernelCall::MemoryAlloc { .. } => {
                // MemoryAlloc not yet implemented
                Ok(TrapResult::Success)
            }
            KernelCall::Abort { reason } => {
                self.engine.abort(ctx, reason);
                Ok(TrapResult::Success)
            }
            KernelCall::Commit => {
                let _receipt = self.commit(ctx)?;
                Ok(TrapResult::Success)
            }
            KernelCall::Effect { payload } => {
                let key = self.effect(ctx, payload)?;
                Ok(TrapResult::EffectKey(key))
            }
            KernelCall::Savepoint { name } => {
                self.savepoint(ctx, &name)?;
                Ok(TrapResult::Success)
            }
            KernelCall::RollbackTo { name } => {
                self.rollback_to(ctx, &name)?;
                Ok(TrapResult::Success)
            }
        }
    }

    // Each method delegates directly to the corresponding VeritasEngine method.

    pub fn last_dependency_invalidations(&self) -> Vec<(ObjectId, ObjectId)> {
        self.engine.last_dependency_invalidations()
    }

    pub fn get_object_state(&self, object_id: ObjectId) -> Option<ObjectState> {
        self.engine.get_object_state(object_id)
    }

    pub fn is_object_dead(&self, object_id: ObjectId) -> bool {
        self.engine.is_object_dead(object_id)
    }

    pub fn list_object_ids(&self) -> Vec<ObjectId> {
        self.engine.list_object_ids()
    }

    pub(crate) fn attach_capability(&self, ctx: &mut TransactionContext, cap_id: u64) {
        self.engine.attach_capability(ctx, cap_id)
    }

    pub fn holds_capability(&self, cap_id: CapabilityId, holder: ObjectId) -> bool {
        self.engine.holds_capability(cap_id, holder)
    }

    pub fn capability_sequence(&self) -> u64 {
        self.engine.capability_sequence()
    }

    pub fn has_link(&self, from: ObjectId, to: ObjectId) -> bool {
        self.engine.has_link(from, to)
    }

    /// Read-only topology snapshot for World API / system software.
    pub fn list_links(&self) -> Vec<crate::types::LinkSnapshot> {
        self.engine.snapshot_links()
    }

    pub fn create_checkpoint(&self) -> WorldSnapshot {
        self.engine.create_checkpoint()
    }

    pub fn restore_checkpoint(&self, snap: &WorldSnapshot) -> bool {
        self.engine.restore_checkpoint(snap)
    }

    pub fn state_root(&self) -> u64 {
        self.engine.state_root()
    }

    pub fn peek_state(&self, state_id: StateId) -> Option<StateEntry> {
        self.engine.peek_state(state_id)
    }

    pub fn get_global_version(&self) -> Version {
        self.engine.get_global_version()
    }

    pub fn get_last_applied_delta_hash(&self) -> [u8; 32] {
        self.engine.get_last_applied_delta_hash()
    }

    // ----- Runtime-internal mutation surface (Machine / WorldService only) -----
    // External production code must use handle() or WorldService.
    // Integration tests use crate::test_api::KernelTestExt.

    pub(crate) fn begin(&self) -> TransactionContext {
        self.engine.begin()
    }

    pub(crate) fn begin_in_object(&self, object_id: ObjectId) -> TransactionContext {
        self.engine.begin_in_object(object_id)
    }

    pub(crate) fn read(
        &self,
        ctx: &mut TransactionContext,
        state_id: StateId,
    ) -> Result<Vec<u8>, VeritasError> {
        self.engine.read(ctx, state_id)
    }

    pub(crate) fn write(
        &self,
        ctx: &mut TransactionContext,
        state_id: StateId,
        payload: Vec<u8>,
    ) -> Result<(), VeritasError> {
        self.engine.write(ctx, state_id, payload)
    }

    pub(crate) fn effect(
        &self,
        ctx: &mut TransactionContext,
        payload: Vec<u8>,
    ) -> Result<String, VeritasError> {
        self.engine.effect(ctx, payload)
    }

    pub(crate) fn commit(
        &self,
        ctx: &mut TransactionContext,
    ) -> Result<TransactionReceipt, VeritasError> {
        self.engine.commit(ctx)
    }

    pub(crate) fn init_state_in_tx(
        &self,
        ctx: &mut TransactionContext,
        state_id: StateId,
        initial_value: Vec<u8>,
    ) {
        self.engine.init_state_in_tx(ctx, state_id, initial_value)
    }

    pub(crate) fn savepoint(
        &self,
        ctx: &mut TransactionContext,
        name: &str,
    ) -> Result<(), VeritasError> {
        self.engine.savepoint(ctx, name)
    }

    pub(crate) fn rollback_to(
        &self,
        ctx: &mut TransactionContext,
        name: &str,
    ) -> Result<(), VeritasError> {
        self.engine.rollback_to(ctx, name)
    }
}

#[cfg(test)]
mod kernel_tests {
    use super::*;

    #[test]
    fn test_kernel_creation() {
        let kernel = Kernel::new();
        let ctx = kernel.begin();
        assert_eq!(ctx.tx_id, 1);
    }

    // ===== Phase 1 Step 5: Kernel ABI boundary tests =====
    // These test the public TRAP -> KernelCall -> Kernel::handle() path.

    #[test]
    fn kernel_survives_multiple_machine_runs() {
        use std::sync::Arc;
        let kernel = Arc::new(Kernel::new());
        {
            let _machine1 = crate::machine::Machine::new(Arc::clone(&kernel));
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 10).unwrap();
            kernel.engine.object_birth(&mut ctx, 20).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();
        }
        {
            let _machine2 = crate::machine::Machine::new(Arc::clone(&kernel));
            assert_eq!(kernel.get_object_state(10), Some(ObjectState::Alive));
            assert_eq!(kernel.get_object_state(20), Some(ObjectState::Alive));
        }
        assert_eq!(kernel.get_object_state(10), Some(ObjectState::Alive));
        assert_eq!(kernel.get_object_state(20), Some(ObjectState::Alive));
    }

    #[test]
    fn kernel_persists_object_across_machines() {
        let kernel = Kernel::new();
        let mut ctx = kernel.begin();
        kernel.engine.object_birth(&mut ctx, 42).unwrap();
        let _receipt = kernel.commit(&mut ctx).unwrap();
        let ctx2 = kernel.begin();
        assert_eq!(kernel.get_object_state(42), Some(ObjectState::Alive));
        drop(ctx2);
    }

    #[test]
    fn kernel_state_independent_of_machine_lifetime() {
        let kernel = Kernel::new();
        {
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 100).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();
        }
        assert_eq!(kernel.get_object_state(100), Some(ObjectState::Alive));
        let ctx = kernel.begin();
        assert_eq!(kernel.get_object_state(100), Some(ObjectState::Alive));
        drop(ctx);
    }

    #[test]
    fn kernel_object_id_monotonic_across_machines() {
        let kernel = Kernel::new();
        let mut ctx1 = kernel.begin();
        kernel.engine.object_birth(&mut ctx1, 1).unwrap();
        kernel.engine.object_birth(&mut ctx1, 2).unwrap();
        let _receipt = kernel.commit(&mut ctx1).unwrap();
        let mut ctx2 = kernel.begin();
        kernel.engine.object_birth(&mut ctx2, 3).unwrap();
        let _receipt = kernel.commit(&mut ctx2).unwrap();
        assert_eq!(kernel.get_object_state(1), Some(ObjectState::Alive));
        assert_eq!(kernel.get_object_state(2), Some(ObjectState::Alive));
        assert_eq!(kernel.get_object_state(3), Some(ObjectState::Alive));
    }

    #[test]
    fn kernel_shared_by_multiple_machines() {
        use std::sync::Arc;
        let kernel = Arc::new(Kernel::new());
        {
            let _machine1 = crate::machine::Machine::new(Arc::clone(&kernel));
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 77).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();
        }
        {
            let _machine2 = crate::machine::Machine::new(Arc::clone(&kernel));
            assert_eq!(kernel.get_object_state(77), Some(ObjectState::Alive));
        }
        assert_eq!(kernel.get_object_state(77), Some(ObjectState::Alive));
    }

    #[test]
    fn abi_trap_object_birth_via_handle() {
        let kernel = Kernel::new();
        let mut ctx = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let result = kernel.handle(&mut ctx, call).unwrap();
        let id = match result {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        assert!(id > 0);
        let _receipt = kernel.commit(&mut ctx).unwrap();
        assert_eq!(kernel.get_object_state(id), Some(ObjectState::Alive));
    }

    #[test]
    fn abi_trap_object_link_via_handle() {
        let kernel = Kernel::new();

        // Create object A
        let mut ctx_a = kernel.begin();
        let call_a = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id_a = match kernel.handle(&mut ctx_a, call_a).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx_a).unwrap();

        // Create object B under A so A receives creator AdminCap on B
        // (STRICT CAPABILITY MODEL: CapabilityGrant requires AdminCap(resource)).
        let mut ctx_b = kernel.begin_in_object(id_a);
        let call_b = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id_b = match kernel.handle(&mut ctx_b, call_b).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx_b).unwrap();

        let mut ctx_link = kernel.begin_in_object(id_a);
        let _cap = kernel
            .engine
            .capability_grant(&mut ctx_link, id_a, id_a, "link", id_b)
            .unwrap();
        let call_link = KernelCall::ObjectLink {
            from: id_a,
            to: id_b,
            link_type: LinkType::DependsOn,
        };
        let result = kernel.handle(&mut ctx_link, call_link).unwrap();
        assert!(matches!(result, TrapResult::Success));
        let _receipt = kernel.commit(&mut ctx_link).unwrap();

        assert!(kernel.has_link(id_a, id_b));
    }

    #[test]
    fn abi_trap_object_freeze_via_handle() {
        let kernel = Kernel::new();
        let mut ctx1 = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id = match kernel.handle(&mut ctx1, call).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx1).unwrap();

        let mut ctx2 = kernel.begin_in_object(id);
        let result = kernel
            .handle(&mut ctx2, KernelCall::ObjectFreeze { object_id: id })
            .unwrap();
        assert!(matches!(result, TrapResult::Success));
        let _receipt = kernel.commit(&mut ctx2).unwrap();

        assert_eq!(kernel.get_object_state(id), Some(ObjectState::Frozen));
    }

    #[test]
    fn abi_trap_object_death_via_handle() {
        let kernel = Kernel::new();
        let mut ctx1 = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id = match kernel.handle(&mut ctx1, call).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx1).unwrap();

        let mut ctx2 = kernel.begin_in_object(id);
        let result = kernel
            .handle(&mut ctx2, KernelCall::ObjectDeath { object_id: id })
            .unwrap();
        assert!(matches!(result, TrapResult::Success));
        let _receipt = kernel.commit(&mut ctx2).unwrap();

        assert_eq!(kernel.get_object_state(id), Some(ObjectState::Dead));
    }

    #[test]
    fn abi_trap_invalid_service_id_rejected() {
        // Invalid service_id is handled at Machine TRAP decoder level.
        // KernelCall enum prevents invalid states at compile time.
        assert!(true);
    }

    #[test]
    fn abi_trap_result_writes_to_register_r0() {
        let kernel = Kernel::new();
        let mut ctx = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let result = kernel.handle(&mut ctx, call).unwrap();
        match result {
            TrapResult::ObjectId(id) => assert!(id > 0),
            _ => panic!("Expected ObjectId from ObjectBirth"),
        }
    }

    // ===== Phase 1 Step 7: ABI encoding boundary tests =====

    #[test]
    fn abi_decode_valid_service_ids() {
        assert!(KernelCall::decode(0, 0, 0, 0).is_ok());
        assert!(KernelCall::decode(1, 42, 0, 0).is_ok());
        assert!(KernelCall::decode(2, 10, 20, 0).is_ok());
        assert!(KernelCall::decode(3, 10, 20, 0).is_ok());
        assert!(KernelCall::decode(4, 99, 0, 0).is_ok());
    }

    #[test]
    fn abi_decode_invalid_service_id_rejected() {
        assert!(KernelCall::decode(99, 0, 0, 0).is_err());
        assert!(KernelCall::decode(255, 0, 0, 0).is_err());
    }

    #[test]
    fn abi_decode_invalid_link_type_rejected() {
        assert!(KernelCall::decode(2, 10, 20, 99).is_err());
    }

    #[test]
    fn abi_decode_object_type_state() {
        let call = KernelCall::decode(0, 0, 0, 0).unwrap();
        match call {
            KernelCall::ObjectBirth { object_type } => {
                assert!(matches!(object_type, ObjectType::StateObject));
            }
            _ => panic!("Expected ObjectBirth"),
        }
    }

    #[test]
    fn abi_decode_object_type_module() {
        let call = KernelCall::decode(0, 1, 0, 0).unwrap();
        match call {
            KernelCall::ObjectBirth { object_type } => {
                assert!(matches!(object_type, ObjectType::ModuleObject));
            }
            _ => panic!("Expected ObjectBirth"),
        }
    }

    #[test]
    fn abi_full_trap_roundtrip() {
        // Full TRAP ABI roundtrip: registers -> decode -> handle -> commit
        let kernel = Kernel::new();

        // Create object via decode + handle
        let mut ctx = kernel.begin();
        let call = KernelCall::decode(0, 0, 0, 0).unwrap();
        let result = kernel.handle(&mut ctx, call).unwrap();
        let id = match result {
            TrapResult::ObjectId(id) => id,
            _ => panic!("Expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx).unwrap();

        assert!(id > 0);
        assert_eq!(kernel.get_object_state(id), Some(ObjectState::Alive));
    }

    // ===== Phase A: Kernel as persistent world tests =====

    #[test]
    fn kernel_survives_multiple_execute_calls() {
        use std::sync::Arc;
        let kernel = Arc::new(Kernel::new());

        // First execution: create an object
        {
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 1).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();
        }

        // Second execution: read the object (same kernel world)
        {
            let ctx = kernel.begin();
            assert_eq!(kernel.get_object_state(1), Some(ObjectState::Alive));
            drop(ctx);
        }

        // Object persists beyond both execution contexts
        assert_eq!(kernel.get_object_state(1), Some(ObjectState::Alive));
    }

    #[test]
    fn kernel_world_persists_across_sequential_machines() {
        use std::sync::Arc;
        let kernel = Arc::new(Kernel::new());

        // Machine 1: create objects
        {
            let _m1 = crate::machine::Machine::new(Arc::clone(&kernel));
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 100).unwrap();
            kernel.engine.object_birth(&mut ctx, 200).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();
        }

        // Machine 2: sees all objects from Machine 1
        {
            let _m2 = crate::machine::Machine::new(Arc::clone(&kernel));
            assert_eq!(kernel.get_object_state(100), Some(ObjectState::Alive));
            assert_eq!(kernel.get_object_state(200), Some(ObjectState::Alive));
        }

        // Kernel world is the source of truth, not any Machine
        assert_eq!(kernel.get_object_state(100), Some(ObjectState::Alive));
        assert_eq!(kernel.get_object_state(200), Some(ObjectState::Alive));
    }

    #[test]
    fn kernel_capability_persists_across_machines() {
        use std::sync::Arc;
        let kernel = Arc::new(Kernel::new());

        // Machine 1: create object and grant capability
        {
            let _m1 = crate::machine::Machine::new(Arc::clone(&kernel));
            let mut ctx = kernel.begin();
            kernel.engine.object_birth(&mut ctx, 10).unwrap();
            let _receipt = kernel.commit(&mut ctx).unwrap();

            let mut ctx2 = kernel.begin();
            kernel
                .engine
                .capability_grant(&mut ctx2, 10, 10, "read", 10)
                .unwrap();
            let _receipt = kernel.commit(&mut ctx2).unwrap();
        }

        // Machine 2: capability still valid
        {
            let _m2 = crate::machine::Machine::new(Arc::clone(&kernel));
            // Object 10 holds a capability on itself (AdminCap from birth + read grant)
            assert!(
                kernel.holds_capability(kernel.capability_sequence(), 10)
                    || kernel.get_object_state(10) == Some(ObjectState::Alive)
            );
        }
    }

    /// ObjectId allocation: fresh Kernel assigns 1, then 2.
    #[test]
    fn object_id_allocation_via_trap_path() {
        let kernel = Kernel::new();
        let mut ctx = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id1 = match kernel.handle(&mut ctx, call).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("expected ObjectId"),
        };
        assert_eq!(id1, 1, "first allocated ObjectId must be 1");

        let id2 = match kernel
            .handle(
                &mut ctx,
                KernelCall::ObjectBirth {
                    object_type: ObjectType::StateObject,
                },
            )
            .unwrap()
        {
            TrapResult::ObjectId(id) => id,
            _ => panic!("expected ObjectId"),
        };
        assert_eq!(id2, 2, "second allocated ObjectId must be 2");
    }

    /// ObjectId after commit: birth via TRAP path survives commit.
    #[test]
    fn object_id_allocation_committed_object_visible() {
        let kernel = Kernel::new();
        let mut ctx = kernel.begin();
        let call = KernelCall::ObjectBirth {
            object_type: ObjectType::StateObject,
        };
        let id = match kernel.handle(&mut ctx, call).unwrap() {
            TrapResult::ObjectId(id) => id,
            _ => panic!("expected ObjectId"),
        };
        let _receipt = kernel.commit(&mut ctx).unwrap();
        assert_eq!(
            kernel.get_object_state(id),
            Some(ObjectState::Alive),
            "committed birth must be visible in registry"
        );
    }

    /// ObjectId after recovery: counter resumes from max(birth_id)+1.
    #[test]
    fn object_id_allocation_resumes_after_commit() {
        use tempfile::NamedTempFile;
        let tmp = NamedTempFile::new().unwrap();
        let path = tmp.path().to_str().unwrap().to_string();

        let engine1 = crate::engine::VeritasEngine::with_wal_path(path.clone());
        let mut ctx = engine1.begin();
        engine1.object_birth(&mut ctx, 10).unwrap();
        let _receipt = engine1.commit(&mut ctx).unwrap();
        drop(engine1);

        let engine2 = crate::engine::VeritasEngine::with_wal_path(path.clone());
        assert_eq!(
            engine2.next_object_id(),
            11,
            "recovered engine must start counter from max(birth_id)+1"
        );
        assert_eq!(
            engine2.get_object_state(10),
            Some(ObjectState::Alive),
            "recovered birth must still be Alive"
        );
    }
}
